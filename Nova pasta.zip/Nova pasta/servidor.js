const http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require("mongodb");
require('colors');

const app = express();

// Configurações do Express
app.use(express.static('./public'));
app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.urlencoded({ extended: true })); // Recomendado true
app.use(bodyParser.json());

// String de conexão
const uri = `mongodb+srv://<usuario>:<senha>@mongofullstack.hwnzwav.mongodb.net/?appName=MongoFullStack`;
const client = new MongoClient(uri);

let usuarios;

// Função para conectar ao banco de dados antes de subir o servidor
async function conectarBanco() {
    try {
        await client.connect();
        const dbo = client.db("bd_completo");
        usuarios = dbo.collection("usuarios");
        console.log("Conectado ao MongoDB com sucesso!".green);
    } catch (e) {
        console.error("Erro ao conectar ao banco:".red, e);
    }
}

conectarBanco().then(() => {
    const server = http.createServer(app);
    server.listen(80, () => {
        console.log('Servidor Funcionando (porta 80)'.rainbow);
    });
});

app.get('/', (req, res) => {
    res.redirect("/usuarios/cadastro.html"); // Verifique se este caminho existe em /public
});

app.get('/cadastro', function (req, res) {
    const { nome, sobrenome, nascimento, civil } = req.query;
    res.render('resposta_cadastro', { nome, sobrenome, nascimento, civil });
});

app.post("/cadastrar_usuario", async function(req, resp) {
    try {
        let data = { 
            db_nome: req.body.nome, 
            db_login: req.body.login, 
            db_senha: req.body.senha 
        };

        await usuarios.insertOne(data);
        resp.render('resposta_usuario.ejs', { resposta: "Usuário cadastrado com sucesso!" });
    } catch (err) {
        console.error(err);
        resp.render('resposta_usuario.ejs', { resposta: "Erro ao cadastrar usuário!" });
    }
});

// Login de Usuário
app.post("/logar_usuario", async function(req, resp) {
    try {
        let query = { db_login: req.body.login, db_senha: req.body.senha };
        const user = await usuarios.findOne(query);

        if (!user) {
            resp.render('resposta_usuario.ejs', { resposta: "Usuário/senha não encontrado!" });
        } else {
            resp.render('resposta_usuario.ejs', { resposta: "Usuário logado com sucesso!" });
        }
    } catch (err) {
        resp.render('resposta_usuario.ejs', { resposta: "Erro ao logar usuário!" });
    }
});

// Listagem de Usuários
app.get("/listar_usuarios", async function(req, resp) {
    try {
        const items = await usuarios.find().toArray();
        resp.render("lista_usuarios.ejs", { usuarios: items });
    } catch (err) {
        resp.status(500).send("Erro ao listar usuários");
    }
});

app.post("/atualizar_usuario", async function(req, resp) {
	try {
		var filtro = { db_login: req.body.login, db_senha: req.body.senha };
		var newData = { $set: { db_senha: req.body.novasenha } };
		const result = await usuarios.updateOne(filtro, newData);
		console.log(result);
		if (result.matchedCount == 0) {
			resp.render('resposta_usuario', { resposta: "Usuário/senha atual não encontrado!" });
		} else {
			resp.render('resposta_usuario', { resposta: "Usuário atualizado com sucesso!" });
		}
	} catch (err) {
	console.error(err);
	resp.render('resposta_usuario', { resposta: "Erro ao atualizar usuário!" });
	}
});

app.post("/remover_usuario", async function(req, resp) {
	try {
		var filtro = { db_login: req.body.login, db_senha: req.body.senha };
		const result = await usuarios.deleteOne(filtro);
		console.log(result);
		if (result.deletedCount == 0) {
			resp.render('resposta_usuario', { resposta: "Usuário/senha não encontrado!" });
		} else {
			resp.render('resposta_usuario', { resposta: "Usuário removido com sucesso!" });
		}
	} catch (err) {
	console.error(err);
	resp.render('resposta_usuario', { resposta: "Erro ao remover usuário!" });
	}
});

app.get('/atualizar', (req, res) => {
    res.render('atualizar.ejs');
});

app.get('/remover', (req, res) => {
    res.render('remover.ejs');
});