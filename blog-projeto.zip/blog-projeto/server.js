const http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require("mongodb");

const app = express();

// Configurações do Express
app.use(express.static('./public'));
app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// String de conexão — substitua pelo seu usuário e senha
const uri = `mongodb+srv://ri:r96857412@rian.f8oo5la.mongodb.net/?appName=Rian`;
const client = new MongoClient(uri);

let posts;

async function conectarBanco() {
    try {
        await client.connect();
        const dbo = client.db("bd_blog");
        posts = dbo.collection("posts");
        console.log("Conectado ao MongoDB com sucesso!");
    } catch (e) {
        console.error("Erro ao conectar ao banco:", e);
    }
}

conectarBanco().then(() => {
    const server = http.createServer(app);
    server.listen(80, () => {
        console.log('Servidor funcionando na porta 80');
    });
});

// Rota padrão → redireciona para Projects
app.get('/', (req, res) => {
    res.redirect("/projects.html");
});

// Blog — lista todos os posts
app.get('/blog', async (req, res) => {
    try {
        const items = await posts.find().sort({ data: -1 }).toArray();
        res.render('blog.ejs', { posts: items });
    } catch (err) {
        res.status(500).send("Erro ao carregar o blog");
    }
});

// Cadastrar novo post
app.post('/cadastrar_post', async (req, res) => {
    try {
        let data = {
            titulo:   req.body.titulo,
            resumo:   req.body.resumo,
            conteudo: req.body.conteudo,
            data:     new Date()
        };
        await posts.insertOne(data);
        res.redirect('/blog');
    } catch (err) {
        console.error(err);
        res.send("Erro ao cadastrar post!");
    }
});
