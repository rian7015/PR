const express = require('express')
const mongoose = require('mongoose')
const session = require('express-session')
const methodOverride = require('method-override')

const app = express()

// Conectar no banco de dados
mongoose.connect('mongodb://localhost:27017/carros_db')
  .then(() => console.log('Banco de dados conectado!'))
  .catch(() => console.log('Erro ao conectar no banco!'))

// Configurações básicas
app.set('view engine', 'ejs')
app.use(express.urlencoded({ extended: true }))
app.use(express.static('public'))
app.use(methodOverride('_method'))
app.use(session({ secret: 'segredo123', resave: false, saveUninitialized: false }))

// Rotas
app.use('/', require('./routes/index'))
app.use('/usuarios', require('./routes/usuarios'))
app.use('/carros', require('./routes/carros'))

// Iniciar servidor na porta 80
app.listen(80, () => {
  console.log('Servidor rodando em http://localhost')
})
