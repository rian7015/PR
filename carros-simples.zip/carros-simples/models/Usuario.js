const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')

const usuarioSchema = new mongoose.Schema({
  nome: String,
  login: String,
  senha: String
})

// Antes de salvar, criptografar a senha
usuarioSchema.pre('save', async function() {
  this.senha = await bcrypt.hash(this.senha, 10)
})

module.exports = mongoose.model('Usuario', usuarioSchema)
