const express = require('express')
const router = express.Router()
const bcrypt = require('bcryptjs')
const Usuario = require('../models/Usuario')

// Página de cadastro
router.get('/cadastro', (req, res) => {
  res.render('cadastro', { erro: null })
})

// Cadastrar usuário
router.post('/cadastro', async (req, res) => {
  const { nome, login, senha } = req.body

  const usuarioExiste = await Usuario.findOne({ login: login })
  if (usuarioExiste) {
    return res.render('cadastro', { erro: 'Esse login já está em uso!' })
  }

  await Usuario.create({ nome, login, senha })
  res.redirect('/usuarios/login')
})

// Página de login
router.get('/login', (req, res) => {
  res.render('login', { erro: null })
})

// Fazer login
router.post('/login', async (req, res) => {
  const { login, senha } = req.body

  const usuario = await Usuario.findOne({ login: login })
  if (!usuario) {
    return res.render('login', { erro: 'Login ou senha incorretos!' })
  }

  const senhaCorreta = await bcrypt.compare(senha, usuario.senha)
  if (!senhaCorreta) {
    return res.render('login', { erro: 'Login ou senha incorretos!' })
  }

  req.session.usuario = usuario.nome
  res.redirect('/carros')
})

// Sair
router.get('/logout', (req, res) => {
  req.session.destroy()
  res.redirect('/usuarios/login')
})

module.exports = router
