const express = require('express')
const router = express.Router()
const Carro = require('../models/Carro')

// Verificar se o usuário está logado
function verificarLogin(req, res, next) {
  if (req.session.usuario) {
    next()
  } else {
    res.redirect('/usuarios/login')
  }
}

// Listar todos os carros
router.get('/', verificarLogin, async (req, res) => {
  const carros = await Carro.find()
  res.render('carros', { carros: carros, usuario: req.session.usuario, mensagem: null })
})

// Cadastrar novo carro
router.post('/cadastrar', verificarLogin, async (req, res) => {
  const { marca, modelo, ano, qtde_disponivel } = req.body
  await Carro.create({ marca, modelo, ano, qtde_disponivel })
  res.redirect('/carros')
})

// Página de editar carro
router.get('/editar/:id', verificarLogin, async (req, res) => {
  const carro = await Carro.findById(req.params.id)
  res.render('editar', { carro: carro })
})

// Salvar edição do carro
router.post('/editar/:id', verificarLogin, async (req, res) => {
  const { marca, modelo, ano, qtde_disponivel } = req.body
  await Carro.findByIdAndUpdate(req.params.id, { marca, modelo, ano, qtde_disponivel })
  res.redirect('/carros')
})

// Remover carro
router.post('/remover/:id', verificarLogin, async (req, res) => {
  await Carro.findByIdAndDelete(req.params.id)
  res.redirect('/carros')
})

// Vender carro (diminui 1 do estoque)
router.post('/vender/:id', verificarLogin, async (req, res) => {
  const carro = await Carro.findById(req.params.id)
  const carros = await Carro.find()

  if (carro.qtde_disponivel <= 0) {
    return res.render('carros', { 
      carros: carros, 
      usuario: req.session.usuario,
      mensagem: 'Estoque Esgotado! Não há unidades disponíveis deste carro.'
    })
  }

  carro.qtde_disponivel = carro.qtde_disponivel - 1
  await carro.save()
  res.redirect('/carros')
})

module.exports = router
